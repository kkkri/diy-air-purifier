#ifndef CIRCULAR_QUEUE_H
#define CIRCULAR_QUEUE_H

#include <stdint.h>
#include <stddef.h>

// Template for a circular queue
template <typename T, size_t Size>
class CircularQueue {
private:
    T buffer[Size];       // Buffer to store queue elements
    size_t head;          // Index of the head
    size_t tail;          // Index of the tail
    size_t count;         // Number of elements in the queue

public:
    CircularQueue() : head(0), tail(0), count(0) {}

    // Add an element to the queue
    bool enqueue(const T& item) {
        if (isFull()) return false; // Queue is full
        buffer[tail] = item;
        tail = (tail + 1) % Size;
        count++;
        return true;
    }

    // Remove and return an element from the queue
    bool dequeue(T& item) {
        if (isEmpty()) return false; // Queue is empty
        item = buffer[head];
        head = (head + 1) % Size;
        count--;
        return true;
    }

    // Check if the queue is empty
    bool isEmpty() const {
        return count == 0;
    }

    // Check if the queue is full
    bool isFull() const {
        return count == Size;
    }

    // Get the number of elements in the queue
    size_t size() const {
        return count;
    }

    // Get the capacity of the queue
    size_t capacity() const {
        return Size;
    }
};

#endif // CIRCULAR_QUEUE_H
